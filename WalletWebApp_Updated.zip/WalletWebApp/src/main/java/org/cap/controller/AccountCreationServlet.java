package org.cap.controller;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;
import org.cap.util.Utility;

/**
 * Servlet implementation class AccountCreationServlet
 */
@WebServlet("/AccountCreationServlet")
public class AccountCreationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ICustomerService customerService;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String accountType=request.getParameter("accountType");
		String balance=request.getParameter("balance");
		
		String description=request.getParameter("description");
		
		customerService=new CustomerServiceImpl();
		
		Account account=new Account();
		account.setAccountType(Utility.findAccountType(accountType));
		account.setOpeningBalance(Double.parseDouble(balance));
		account.setDescription(description);
		account.setOpeningDate(LocalDateTime.now());
		
		HttpSession session= request.getSession(false);
		Integer custId=Integer.parseInt(session.getAttribute("custId").toString());
		
		Customer customer=customerService.findCustomerById(custId);
		account.setCustomer(customer);
		
		Account account2=customerService.createAccount(account);
		if(account2 !=null)
			request.getRequestDispatcher("pages/createAccount.html").forward(request, response);
		
	}

}
