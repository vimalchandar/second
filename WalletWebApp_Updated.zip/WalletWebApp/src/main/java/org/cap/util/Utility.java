package org.cap.util;

public class Utility {
	
	public static AccountType findAccountType(String accType) {
		switch (accType) {
		case "Savings":
			return AccountType.SAVINGS;
			
		case "Current":
			
			return AccountType.CURRENT;
		case "rd":
	
			return AccountType.RD;
		case "fd":
	
			return AccountType.FD;
		case "loan":
	
			return AccountType.LOAN;

		
		}
		return null;
	}

}
