package com.capge.lab6.labbook;

public class Account62 {
	long accnum;
	double balance;
	Person accholder;
	void deposit(double amount){
		this.balance+=amount;
	}
	boolean withdraw(double amount)
	{
		if(this.balance-amount>0)
			this.balance-=amount;
		return false;
	}
	double getbalance(){
		return this.balance;
	}
	public String toString(){
		return String.format("name: "+this.accholder.getname()+"balance: "+this.getbalance()+"account "+this.accnum);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account62 acc1;
		Account62 acc2;
		try {
			acc1=new CurrentAccount("Smith",14,2000);
			acc1.deposit(2000);
			System.out.println(acc1);
			
		} catch (Invalidage e) {
			// TODO: handle exception
			System.out.println(e.getMessage()+"not eligible to create account");
		}
		try {
			acc2=new SavingsAccount("Kathy",30,3000);
			acc2.deposit(2000);
			System.out.println(acc2);
			
		} catch (Invalidage e) {
			// TODO: handle exception
			System.out.println(e.getMessage()+"not eligible to create account");
		}
	}

public Account62(String name,float age,double balance) {
	// TODO Auto-generated constructor stub
	this.accholder=new Person();
	this.accholder.setname(name);
	this.accholder.setage(age);
	this.balance =balance;
	this.accnum=(long)(Math.random()*1000000);
	
}
}
class Person{
private String name;
private float age;
public String getname() {
	return this.name;
}
public void setname(String name) {
	this.name=name;
}

public float getage() {
	return this.age;
}
public void setage(float age) {
	if(age<=15){
	throw new Invalidage (this.name);
}
else
	this.age=age;
}
}
class CurrentAccount extends Account62{
	final float overdraftLimit=-500;
	public static void main(String args[]) {
		Account62 acc1=new CurrentAccount("Kathy",30,3000);
		acc1.withdraw(3600);
		System.out.println(acc1.getbalance());
	}
	public CurrentAccount(String name,float age,double balance) {
		// TODO Auto-generated constructor stub
		super(name,age,balance);
	}
	boolean withdraw(double amount){
		if(this.balance-amount>overdraftLimit){
			this.balance-=amount;
			return true;
		}
		else {
			System.out.println(this.accholder.getname()+"Overdraft limit exceeded");
			return false;
		}
	}
}
class SavingsAccount extends Account62{
	 float overdraftLimit=-500;
	public static void main(String[] args) {
		Account62 acc1=new CurrentAccount("Smith",25,2000);
		acc1.withdraw(1600);
	}
		public SavingsAccount(String name,float age,double balance) {
			// TODO Auto-generated constructor stub
			super(name,age,balance);
		}
		boolean withdraw(double amount){
			if(this.balance-amount>500){
				this.balance-=amount;
				return true;
			}
			else {
				System.out.println(this.accholder.getname()+"minimum balance of 500 must be there");
				System.out.println(this.accholder.getname()+"Current balance is"+this.getbalance());
				return false;
			}
		}
		
	}
class Invalidage extends RuntimeException{
	public Invalidage(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}
}
