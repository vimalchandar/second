package com.capge.lab6.labbook;

import java.util.Scanner;

import org.omg.CORBA.ORBPackage.InvalidName;

public class Personmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Personclass61 p1=new Personclass61();
		p1.details();
		Scanner sc=new Scanner(System.in);
		System.out.println("\n\nenter first name");
		String First_name=sc.nextLine().toUpperCase().trim();
		try {
			System.out.println("enter last name");
			String last_name=sc.nextLine().toUpperCase().trim();
			if((First_name.length()==0)&&(last_name.length()==0))
			{
				sc.close();
			throw new InvalidName("Error");
	     	}
		System.out.println("Enter gender");
		String g;
		char Gender;
		while(true){
			g=sc.next();
			if(g.equalsIgnoreCase("M")||g.equalsIgnoreCase("F"))
			{
				Gender =g.toString().charAt(0);
				break;
			}
			else
			{
				System.out.println("enter correctly");
			}
	}
		sc.close();
		Personclass61 p2=new Personclass61(First_name,last_name,Gender);
		p2.details();

}
	catch(InvalidName e)
	{
		System.out.println("Enter name correctly");
	}
}
}
	 class Personclass61{
		private String firstname,lastname;
		private char gender;
		public Personclass61(String firstname,String lastname,char gender){
			this.firstname=firstname;
			this.lastname=lastname;
			this.gender=gender;
		}
		public Personclass61()
		{
			firstname="Keerthanadevi";
			lastname="T";
			gender='M';
		}
		public void details(){
			System.out.println("Person Details:\n_______________\nFirst Name"+firstname.toUpperCase());
			System.out.println("Last Name: "+lastname.toUpperCase()+"\nGender: "+gender);
			
		}
		
	}
	 class Invalidname extends RuntimeException
	 {
		 public Invalidname(String s) {
			// TODO Auto-generated constructor stub
			 super(s);
		 }
	 }

