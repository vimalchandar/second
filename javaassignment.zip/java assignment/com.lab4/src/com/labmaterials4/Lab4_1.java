package com.labmaterials4;
class Person
{
	Person(String x,int y)
	{
		this.name=x;
		this.age=y;
	}
	String name;
	int age;
}
public class Lab4_1 {


	static int i=0;
	long accNum;
	double balance;
	Person accHolder;
	Lab4_1(double b,Person obb)
	{
		//super();
		this.accNum=++i;
		this.balance=b;
	}
	void deposit(double a)
	{
		this.balance+=a;
	}
	void withdraw(double a)
	{
		double c=balance-a;
		if(c<500)
		{
			System.out.println("Check ur balance bro");
		}
		else
		this.balance-=a;
	}
	void getBalance(Person obb)
	{
		System.out.println(obb.name+" "+obb.age+"yrs "+this.accNum+" "+this.balance+"Rs ");
		//return this.balance;
	}
	public String toString()
	{
		return "Balance "+balance+" AccNum"+accNum;
	}
	public static void main(String[] args)
	{
		Person obb = new Person("Smith",21);
		Lab4_1 obj = new Lab4_1(2000,obb);
		Person obb1 = new Person("Kathy",42);
		Lab4_1 obj1 = new Lab4_1(3000,obb1);
		obj.getBalance(obb);
		obj1.getBalance(obb1);
		obj.deposit(2000);
		obj1.withdraw(2000);
		obj.getBalance(obb);
		obj1.getBalance(obb1);
		System.out.println(obj);
	}
}


