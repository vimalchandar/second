package com.labmaterials4;

import java.util.Scanner;

public class Savinglab4_2 extends AccountLab4_2{
	final double minimumBalance=1000;
	@Override
	void withdraw() throws Exception {
		// TODO Auto-generated method stub
		double balance=15000;
		Scanner s=new Scanner(System.in);
		System.out.print("minimumbalance: "+minimumBalance+"\n"+"enter withdraw amount: ");
		int wt=s.nextInt();
		System.out.print("withdraw:"+wt);
		if((balance-wt)>minimumBalance)
		{
			double minimumbalance=balance-wt;
			System.out.println("\nfinal withdraw:"+(balance-wt));
		}
		else {
			System.out.println("insufficient balance");
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			AccountLab4_2 obj=new Savinglab4_2();
			obj.withdraw();
		}catch(Exception e)
		{
			System.out.print("u r not ");
		}

	}

}
