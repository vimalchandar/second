package com.labmaterials4;

import java.util.Scanner;

public class AccountLab4_2 {
	void withdraw() throws Exception{
		Scanner s=new Scanner(System.in);
		System.out.println("enter age:");
		int age=s.nextInt();
		if(age<15)
		{
			throw new Exception("u r a child");
		}
		System.out.print("enter minimum balance:");
		int b=s.nextInt();
		System.out.print("enter minimum balance:"+b);
		System.out.print("enter amount to withdraw:");
		int wt=s.nextInt();
		System.out.print(":"+wt);
		if(b>10000)
		{
			System.out.println("Withdraw:"+(b-wt));
		}
		else {
			System.out.print("insufficient balance");
		}
	}
	void withdraw1()
	{
		double overdraftlimit=100;
		System.out.print("overdraftlimit:"+overdraftlimit+"\n");
	}
}
