package com.labmaterials4;

import java.util.Scanner;

public class Currentlab4_2 extends AccountLab4_2{
double overdraftlimit;
@Override
	void withdraw() throws Exception {
		// TODO Auto-generated method stub
	Scanner s=new Scanner(System.in);
	System.out.print("withdraw amount:");
	int withdraw=s.nextInt();
	System.out.print("Withdraw: "+withdraw+"\n");
	if(overdraftlimit==withdraw)
	{
		System.out.println(true+"\n");
	}
	else {
		System.out.print(false+"\n");
	}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
	AccountLab4_2 obj=new Currentlab4_2();
	obj.withdraw();
} catch (Exception e) {
	// TODO: handle exception
	System.out.print("u r not");
}
	}

}
