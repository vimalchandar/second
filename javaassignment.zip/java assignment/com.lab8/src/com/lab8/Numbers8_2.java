package com.lab8;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Numbers8_2 {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		File f=new File("C:\\Backup\\status.txt");3:40 PM 2/2/2019
		Scanner sc=new Scanner(f);
		Scanner s=sc.useDelimiter(",");
		int i;
	while (s.hasNext()) {
		i=s.nextInt();
		if(i%2==0)
			System.out.println(i);
	}
	s.close();
	sc.close();
	}

}
