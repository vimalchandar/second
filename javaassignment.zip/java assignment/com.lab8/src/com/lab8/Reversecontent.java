package com.lab8;

import java.io.FileReader;
import java.io.FileWriter;

public class Reversecontent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			FileReader f=new FileReader("C:\\Backup\\status.txt");
			int i=0;
			StringBuffer s=new StringBuffer();
			while((i=f.read())!=-1)
			{
				s.append((char)i);
			}
			String h=s.reverse().toString();
			System.out.println(h);
			f.close();
			FileWriter f1=new FileWriter("C:\\Backup\\status.txt");
			f1.write(h);
			f1.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
