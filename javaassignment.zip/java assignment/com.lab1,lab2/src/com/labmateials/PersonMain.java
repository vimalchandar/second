package com.labmateials;

public class PersonMain {
	String firstname;
	String lastname;
	char gender;
	int age;
	double weight;
	public PersonMain()
	{
			
		 System.out.print("Person Details:");
			System.out.println();
		    System.out.println("_______________");
		    System.out.println();
	}
	public PersonMain(String fn,String ln,char g)
	{
		firstname=fn;
		lastname=ln;
		gender=g;
		System.out.println("First Name: "+firstname);
		System.out.println("Last Name: "+lastname);
		System.out.println("Gender: "+gender);
		System.out.println();
	}
	
	
	
	/*public void display()
	{   System.out.print("Person Details:");
		System.out.println();
	    System.out.println("_______________");
	    System.out.println();
		System.out.println("First Name: "+firstname);
		System.out.println("Last Name: "+lastname);
		System.out.println("Gender: "+gender);
		
	
	}*/
	public static void main(String[] args) {
		// TODO Auto-generated method stu
		PersonMain pt=new PersonMain();
		PersonMain pd=new PersonMain("Divya","Bharathi",'F');
		
		//pd.display();
			
	}

}
