package com.labmateials;

public class PersonDetails {
	String firstname;
	String lastname;
	char gender;
	int age;
	double weight;
	public PersonDetails(String fn,String ln,char g,int i,double d)
	{
		firstname=fn;
		lastname=ln;
		gender=g;
		age=i;
		weight=d;
	}
	public void display()
	{   System.out.print("Person Details:");
		System.out.println();
	   System.out.println("_______________");
	   System.out.println();
		System.out.println("First Name: "+firstname);
		System.out.println("Last Name: "+lastname);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+weight);
	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonDetails pd=new PersonDetails("Divya","Bharathi",'F',20,85.55);
		pd.display();

	}

}
