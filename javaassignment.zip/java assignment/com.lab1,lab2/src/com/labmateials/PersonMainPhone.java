package com.labmateials;

import java.util.Scanner;

public class PersonMainPhone {
	String firstname;
	String lastname;
	char gender;
	long phone;
	Scanner sc=new Scanner(System.in);
	public PersonMainPhone()
	{
		 System.out.print("Person Details:");
			System.out.println();
		    System.out.println("_______________");
		    System.out.println();
	}
	public PersonMainPhone(String fn,String ln,char g)
	{
		firstname=fn;
		lastname=ln;
		gender=g;
		System.out.println("First Name: "+firstname);
		System.out.println("Last Name: "+lastname);
		System.out.println("Gender: "+gender);
		//System.out.println();
}
	
	public void phone()
	{  
		phone=sc.nextLong();
		System.out.println("Phone No:"+phone);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonMainPhone pt=new PersonMainPhone();
		PersonMainPhone pd=new PersonMainPhone("Divya","Bharathi",'F');
		pd.phone();
			
		
	}

}

	