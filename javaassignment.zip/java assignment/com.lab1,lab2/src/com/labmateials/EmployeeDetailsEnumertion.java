package com.labmateials;

import java.util.Scanner;

public class EmployeeDetailsEnumertion {

	String firstname;
	String lastname;
	enum gender{
		M,F;
	}
	gender g=gender.F;
	long phone;
	Scanner sc=new Scanner(System.in);
	public EmployeeDetailsEnumertion()
	{
		 System.out.print("Person Details:");
			System.out.println();
		    System.out.println("_______________");
		    System.out.println();
	}
	 public EmployeeDetailsEnumertion(String fn,String ln)
	{
		firstname=fn;
		lastname=ln;
		//gender=g;
		System.out.println("First Name: "+firstname);
		System.out.println("Last Name: "+lastname);
		System.out.println("Gender: "+g);
		//System.out.println();
}
	
	public void phone()
	{  
		phone=sc.nextLong();
		System.out.println("Phone No:"+phone);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDetailsEnumertion pt=new EmployeeDetailsEnumertion();
		EmployeeDetailsEnumertion pd=new EmployeeDetailsEnumertion("Divya","Bharathi");
		pd.phone();
			
		
	}

}

