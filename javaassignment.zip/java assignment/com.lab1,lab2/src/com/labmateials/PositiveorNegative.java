package com.labmateials;

import java.util.Scanner;

public class PositiveorNegative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		if(n>0)
			System.out.println(n +" is positive");
		else {
			System.out.println(n +" is negative");
		}

	}

}
