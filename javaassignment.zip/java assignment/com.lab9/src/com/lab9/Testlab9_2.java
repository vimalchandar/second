package com.lab9;

import static org.junit.Assert.*;

import org.junit.Test;

public class Testlab9_2 {
	@Test
	public void testGetDay()
	{
	   Lab9_2 obj = new Lab9_2(10,02,2019);
	   assertEquals(10,obj.getDay());
	}
	@Test
	public void testGetMonth()
	{
		Lab9_2 obj = new Lab9_2(01,02,2019);
		assertEquals(02,obj.getMonth());
	}
	@Test
	public void testGetYear()
	{
		Lab9_2 obj = new Lab9_2(01,02,2019);
		assertEquals(2019,obj.getYear());
	}
}
