package com.labmaterial;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class Lab3_7b {

		static int aga,a1;
		private String firstname;
		private String lastname;
		void calculateAge()
		{
			LocalDate a1=LocalDate.of(1997, Month.SEPTEMBER, 19);
			LocalDate a=LocalDate.now();
			System.out.println(a1);
			System.out.println(a);
			Period p=a1.until(a);
			System.out.println("Age: "+p.getYears());
			}
		void getfullname(String firstname,String lastname)
		{
			this.firstname=firstname;
			this.lastname=lastname;
			System.out.println(firstname+" "+lastname);
			
		}
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Lab3_7b n=new Lab3_7b();
			n.calculateAge();
			n.getfullname("Vimal Chandar", "M");		}
}
