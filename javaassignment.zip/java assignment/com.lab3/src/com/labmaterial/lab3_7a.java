package com.labmaterial;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class lab3_7a {
static int aga,a1;
void calculateAge()
{
	LocalDate a1=LocalDate.of(1997, Month.SEPTEMBER, 19);
	LocalDate a=LocalDate.now();
	System.out.println(a1);
	System.out.println(a);
	Period p=a1.until(a);
	System.out.println("Age: "+p.getYears());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		lab3_7a n=new lab3_7a();
		n.calculateAge();

	}

}
