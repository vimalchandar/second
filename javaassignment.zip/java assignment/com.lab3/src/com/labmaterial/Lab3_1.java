package com.labmaterial;

import java.util.Scanner;

import javax.lang.model.element.Element;

public class Lab3_1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		System.out.println("Choose an option\n1.Add the string to itself\n2.Replace the odd position\n3.Remove the duplicate\n4.Convert to uppercase");
		int i=sc.nextInt();
		Lab3_1 l=new Lab3_1();
		
		l.options(str, i);
		sc.close();
	}
	void options(String str,int i)
	{
		String s=str,s1="";
		if(i==1)
		{	s=s.concat(str);
			System.out.println(s);
		}
		else if(i==2)
		{
			for (int i1 = 0; i1 <s.length(); i1++){
				if(i1%2==0)
					s1=s1+"#";
				else 
					s1=s1+str.charAt(i1);
				
				
			}
			System.out.println(s1);
		}
		else if(i==3)
		{
			for (int j = 0; j < s.length(); j++) {
				char c=s.charAt(j);
				if(s.indexOf(c)==j)
					s1+=c;
			}
			System.out.println(s1);
		}
		else if (i==4) {
			for (int k = 0; k < s.length(); k++) {
				if(k%2==0)
					s1=s1+str.toUpperCase().charAt(k);
				else 
					s1=s1+str.charAt(k);
				
			}
			System.out.println(s1);
		}
		}
	}
	
