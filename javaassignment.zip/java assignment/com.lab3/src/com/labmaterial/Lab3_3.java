package com.labmaterial;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class Lab3_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate start=LocalDate.now();
		System.out.println("present date: "+start);
		LocalDate end=LocalDate.of(1997, Month.SEPTEMBER, 19);
		System.out.println("Comparing date "+end);
		Period period=start.until(end);
		System.out.println("Days "+period.getDays());
		System.out.println("Months "+period.getMonths());
		System.out.println("years "+period.getYears());

			}

	}

