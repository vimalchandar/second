package com.labmaterial;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class Lab3_4 {

	void method1()
	{
	LocalDate s1=LocalDate.of(1997, Month.SEPTEMBER, 7);
	System.out.println("Local date1:"+s1);
	LocalDate s2=LocalDate.of(2018, Month.DECEMBER, 11);
	System.out.println("Local date2:"+s2);
	Period p=s1.until(s2);
	System.out.println("days:"+p.getDays());
	System.out.println("months:"+p.getMonths());
	System.out.println("years:"+p.getYears());
	}
  public static void main(String args[])
  {
	Lab3_4 obj=new Lab3_4();
	obj.method1();
  }
}
