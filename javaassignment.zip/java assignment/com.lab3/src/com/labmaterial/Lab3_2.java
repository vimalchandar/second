package com.labmaterial;

import java.util.Scanner;

public class Lab3_2 {
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter a string of ur choice::");
		String str=s.next();
		Lab3_2 ps=new Lab3_2();
		System.out.println(ps.check(str));
		s.close();
	}
	public boolean check(String s)
	{
		String[] str=s.split("");
		int l=str.length,j=0,flag=0;
		for(int i=0;i<l-1;i++){
			j=str[i].compareTo(str[i+1]);
			if(j>0){
				flag=1;
				break;
			}
		}
		if(flag==0)
			return true;
		else
			return false;
	}	
}
