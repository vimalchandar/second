package com.lab7;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Lab7_3 {
	int empId;
	String empName;
	int empInsurance;

	Lab7_3(int empId,String empName,int empInsurance)
	{
		this.empId=empId;
		this.empName=empName;
		this.empInsurance=empInsurance;
	}
	 public String toString()
	{
		   return ("\nID: "+this.empId+"\nName: "+this.empName+"\nInsurance: "+this.empInsurance);
	}
		public static void main(String[] args) 
		{
			HashMap<Integer,Lab7_3> employe=new HashMap<Integer,Lab7_3>();
			Scanner s=new Scanner(System.in);
			System.out.println("Enter insurance of employee 1");
			int empInsurance= s.nextInt();
			employe.put(101,new Lab7_3(1,"Ajitha", empInsurance));
			
			System.out.println("Enter insurance of employee 2");
			empInsurance= s.nextInt();
			employe.put(102,new Lab7_3(2,"Aprajitha", empInsurance));
			 for(Map.Entry m:employe.entrySet())
			 {    
		           System.out.println("\nIndex: "+m.getKey()+"\nEmployee details: "+m.getValue());    
		     } 
		}
}
