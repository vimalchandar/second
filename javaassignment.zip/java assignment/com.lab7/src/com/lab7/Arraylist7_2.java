package com.lab7;

import java.util.ArrayList;
import java.util.Scanner;

public class Arraylist7_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> str=new ArrayList<String>();
		Scanner sc=new Scanner(System.in);
		String s1=sc.next();
		while(!(s1.equals("Z")))
		{
			str.add(s1);
			s1=sc.next();
		}
		str.sort(null);
		for(String s2:str)
			System.out.println(s2);
		sc.close();

	}

}
