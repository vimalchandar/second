package com.lab7;

import java.util.Arrays;
import java.util.Scanner;

public class Stringarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] str=new String[3];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<3;i++)
		
			str[i]=sc.next();
		
		Arrays.sort(str);
		for (int i = 0; i < 3; i++) 
			System.out.println(str[i]);
			sc.close();
		
	}

}
