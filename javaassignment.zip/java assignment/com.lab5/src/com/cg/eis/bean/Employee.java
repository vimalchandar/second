package com.cg.eis.bean;



public class Employee {
private double id;
private String name;
private String designation;
private double insuScheme;
private double salary;
public double getSalary()
{
	return salary;
}
public void setSalary(double salary)
{
	this.salary=salary;
}
public double getInsuScheme()
{
	return insuScheme;
}
public void setInsuscheme(double insuscheme)
{
	this.insuScheme=insuscheme;
}
public String getDesignation()
{
	return designation;
}
public void setDesignation(String designation)
{
	this.designation=designation;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name=name;
}
public double getId() {
	return id;
}
public void setId(double id) {
	this.id=id;
}

}
