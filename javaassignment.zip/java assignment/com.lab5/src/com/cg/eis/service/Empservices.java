package com.cg.eis.service;
import java.util.Scanner;

import com.cg.eis.bean.*;
public class Empservices {
public Scanner sc=new Scanner(System.in);
public Employee emp=new Employee();
public void setdetails() {
	System.out.println("enter name:");
	emp.setName(sc.next());
	System.out.println("enter id:");
	emp.setId(sc.nextDouble());
	System.out.println("enter designation: ");
	emp.setDesignation(sc.next());
	System.out.println("enter salary:");
	emp.setSalary(sc.nextDouble());
	
}
public void getdetails() {
	System.out.println(" name:"+emp.getName());
	System.out.println(" id:"+emp.getId());
	System.out.println(" designation:"+emp.getDesignation());
	
	
}
public void scheme() {
	emp.setInsuscheme(emp.getSalary()*100);
	System.out.println("salary:"+emp.getSalary());
	System.out.println("insuScheme:"+emp.getInsuScheme());
}
}
