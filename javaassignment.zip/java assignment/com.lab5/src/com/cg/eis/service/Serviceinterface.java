package com.cg.eis.service;

public interface Serviceinterface {
	void setdetails();
	void getdetails();
	void scheme();
}
