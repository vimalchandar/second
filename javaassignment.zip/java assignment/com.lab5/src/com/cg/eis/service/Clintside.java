package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class Clintside extends Empservices implements Serviceinterface{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Empservices serv=new Empservices();
		Scanner sc=new Scanner(System.in);
		while (true) {
			String input=sc.next();
			switch (input) {
			case "new":
				serv.setdetails();
				break;
			case "scheme":{
				serv.scheme();
				break;
			}
			case "details":{
				serv.getdetails();
				break;
			}

			default:
				System.out.println("option not found");
				break;
			}
		}

	}

	
}
