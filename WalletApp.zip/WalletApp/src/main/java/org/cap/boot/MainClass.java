package org.cap.boot;

import java.util.List;
import java.util.Scanner;

import org.cap.exception.InvalidCustomerIdException;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.service.AccountServiceImpl;
import org.cap.service.IAccountService;
import org.cap.view.UserInteraction;

public class MainClass {
	
	private static IAccountService accountService=new AccountServiceImpl();
	private static UserInteraction ui=new UserInteraction();
	private static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args)  {
		String choice=null;
		boolean flag=false;
		do {
			do {
				List<Customer> customers= accountService.getAllCustomers();
				
				int customerId=ui.chooseCustomer(customers);
				
				flag=accountService.isValidCustomerId(customerId);
				if(flag)
				{
					int option=ui.chooseMenuOption();
					switch (option) {
					case 1:
						Account account=ui.getAccountDetails();
						//Customer customer=accountService.findCustomer(customerId);
						Customer customer=new Customer();
						customer.setCustomerId(customerId);
						account.setCustomer(customer);
						
						Account account1=accountService.createAccount(account);
						
						ui.printAccount(account1);
						
						break;
					case 2:
						List<Account> accounts= accountService.getAllAccountsForCustomer(customerId);
						ui.printAccount(accounts);
					case 3:
						ui.showSubMenu();
						break;
					default:
						System.exit(0);;
					}
				}else {
					try {
						throw new InvalidCustomerIdException("Sorry Customer Id does not exits.");
					} catch (InvalidCustomerIdException e) {
						System.out.println(e.getMessage());
						//e.printStackTrace();
					}
			}
				
				
			}while(!flag);
			System.out.println("Do you want to continue? [Y|N] :");
			choice=sc.next();	
		}while(choice.charAt(0)=='Y' || choice.charAt(0)=='y');
	}

}
