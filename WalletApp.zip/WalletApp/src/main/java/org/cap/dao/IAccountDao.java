package org.cap.dao;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface IAccountDao {
	
	public List<Customer> getAllCustomers();
	public boolean isValidCustomerId(int customerId);
	public Customer findCustomer(int customerId);
	public Account createAccount(Account account);
	public List<Account> getAllAccountsForCustomer(int customerId);

}
