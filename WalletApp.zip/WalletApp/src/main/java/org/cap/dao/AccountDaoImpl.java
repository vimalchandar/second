package org.cap.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;

public class AccountDaoImpl implements IAccountDao {
	
	private static List<Customer> customers=dummyDbCustomers();
	
	private static List<Customer> dummyDbCustomers(){
		List<Customer> customers=new ArrayList<>();
		customers.add(new Customer(1001, "Tom", "Jerry", "435435546", "tom@gmail.com", LocalDate.of(1990, 2, 22), new Address(1, "23/A", "West Car Street", "Chennai", "5634523", "TamilNadu")));
		customers.add(new Customer(1002, "Hari", "Ram", "435435", "ram@gmail.com", LocalDate.of(1989, 2, 1), new Address(1, "23/A", "West Car Street", "Hyderabad", "5634523", "Andra")));
		
		customers.add(new Customer(1003, "Paul", "Jack", "324324", "paul@gmail.com", LocalDate.of(1978, 2, 2), new Address(1, "23/A", "West Car Street", "Chennai", "5634523", "TamilNadu")));
		
		customers.add(new Customer(1004, "Jack", "Thomson", "546546", "jack@gmail.com", LocalDate.of(1977, 2, 11), new Address(1, "23/A", "West Car Street", "Pune", "5634523", "Maharastra")));
		
		customers.add(new Customer(1005, "Annie", "Jack", "45435", "annie@gmail.com", LocalDate.of(1995,6, 29), new Address(1, "23/A", "West Car Street", "Chennai", "5634523", "TamilNadu")));
		
		return customers;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customers;
	}

	@Override
	public boolean isValidCustomerId(int customerId) {
		
		
		for(Customer customer:customers) {
			if(customer.getCustomerId()==customerId)
			{
				return true;
			}
		}
		
		return false;
	}

	@Override
	public Customer findCustomer(int customerId) {
		for(Customer customer:customers) {
			if(customer.getCustomerId()==customerId)
				return customer;
		}
		return null;
	}

	@Override
	public Account createAccount(Account account) {
		
		Customer customer=findCustomer(account.getCustomer().getCustomerId());
		
		ListIterator<Customer>  iterator= customers.listIterator();
		while(iterator.hasNext()) {
			Customer customer2= iterator.next();
			if(customer2.getCustomerId()==account.getCustomer().getCustomerId()) {
				customer2.getAccounts().add(account);
				iterator.set(customer2);
				break;
			}
		}
		
		return account;
	}

	@Override
	public List<Account> getAllAccountsForCustomer(int customerId) {
		for(Customer customer:customers) {
			if(customer.getCustomerId()==customerId) {
				return customer.getAccounts();
			}
		}
		return null;
	}

}
