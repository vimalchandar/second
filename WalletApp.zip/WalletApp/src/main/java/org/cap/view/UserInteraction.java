package org.cap.view;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.util.AccountType;

public class UserInteraction {
	
	Scanner scanner=new Scanner(System.in);
	
	
	public void printAccount(Account account) {
		System.out.println(account.getAccountNo() + "\t"
				+ account.getAccountType()+"\t" 
				+account.getOpeningBalance()+"\t"
				+account.getOpeningDate()+"\t"
				+account.getDescription() );
	}
	
	public Account getAccountDetails() {
		int option=0;
		AccountType accountType=null;
		Account account=new Account();
			do {
			System.out.println("Choose Account Type:");
			for(AccountType type:AccountType.values()) {
				System.out.println(type.getValue() + "." +type);
			}
			option=scanner.nextInt();
			
			switch(option) {
			case 1:
				accountType=AccountType.SAVINGS;
				break;
			case 2:
				accountType=AccountType.CURRENT;
				break;
			case 3:
				accountType=AccountType.RD;
				break;
			case 4:
				accountType=AccountType.FD;
				break;
			case 5:
				accountType=AccountType.LOAN;
				break;
				
			}
		}while(option<1 || option>5);
		account.setAccountType(accountType);
		
		
		System.out.println("Enter opening Balance:");
		double balance=scanner.nextDouble();
		account.setOpeningBalance(balance);
		
		System.out.println("Enter Account Description:");
		String desc=scanner.next();
		account.setDescription(desc);
		
		account.setOpeningDate(LocalDateTime.now());
		
		return account;
	}
	
	
	public int chooseMenuOption() {
		System.out.println("1.Create Account");
		System.out.println("2.List All Accounts");
		System.out.println("3.Perform Transaction");
		System.out.println("4.Exit");
		System.out.println("Enter your option:");
		int option=scanner.nextInt();
		return option;
	}
	
	public void showSubMenu() {
		System.out.println("1.Deposit");
		System.out.println("2.Withdraw");
		System.out.println("3.Fund Transfer");
		System.out.println("4.Print Transactions");
		System.out.println("5.Exit");
	}
	
	public void showAllCustomers(List<Customer> customers) {
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId() +"\t" 
					+ customer.getFirstName() +"\t"
							+ customer.getLastName() +"\t"
							+ customer.getEmailId());
		}
		
		
	}
	
	public int chooseCustomer(List<Customer> customers) {
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId() +"\t" 
					+ customer.getFirstName() +"\t"
							+ customer.getLastName() +"\t"
							+ customer.getEmailId());
		}
		
		System.out.println("Choose CustomerId to create account:");
		int customerId=scanner.nextInt();
		return customerId;
	}

	public void printAccount(List<Account> accounts) {
		
		for(Account account:accounts) {
			printAccount(account);
		}
	}

}
