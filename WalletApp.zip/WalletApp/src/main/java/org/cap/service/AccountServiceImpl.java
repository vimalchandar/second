package org.cap.service;

import java.util.List;

import org.cap.dao.AccountDaoImpl;
import org.cap.dao.IAccountDao;
import org.cap.model.Account;
import org.cap.model.Customer;

public class AccountServiceImpl implements IAccountService{
	
	private IAccountDao accountDao=new AccountDaoImpl();

	@Override
	public List<Customer> getAllCustomers() {
		
		return accountDao.getAllCustomers();
	}

	@Override
	public boolean isValidCustomerId(int customerId) {
		
		return accountDao.isValidCustomerId(customerId);
	}

	@Override
	public Customer findCustomer(int customerId) {
		// TODO Auto-generated method stub
		return accountDao.findCustomer(customerId);
	}

	@Override
	public Account createAccount(Account account) {
		
		//genearte Account Number
		long accountNo=(long)(Math.random()*100000);
		account.setAccountNo(accountNo);
		
		
		return accountDao.createAccount(account);
	}

	@Override
	public List<Account> getAllAccountsForCustomer(int customerId) {
		
		return accountDao.getAllAccountsForCustomer(customerId);
	}

}
