package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HiddenServlet")
public class HiddenServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String color=request.getParameter("color");
		out.println("<h1 style='color:"+color+";'>Hello world</h1>");
		
		
		Cookie cookie=new Cookie("emailId", "tom@capgemini.com");
		cookie.setMaxAge(20);
		response.addCookie(cookie);
		
		out.println("<a href='CookieServlet'>Check Cookeis </a>");
		
		
		
	}

}
