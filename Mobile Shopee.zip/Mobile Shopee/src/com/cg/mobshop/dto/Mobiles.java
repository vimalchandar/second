package com.cg.mobshop.dto;

public class Mobiles {
	public int mobileId;
	public String name;
	public int price;
	public int quantity;
	
	public Mobiles(int mobileId,String name,int price,int quantity)
	{
		this.mobileId=mobileId;
		this.name=name;
		this.price=price;
		this.quantity=quantity;
	}
	public int getmobileId()
	{
		return mobileId;
	}
	public void setmobileId(int mobileId)
	{
		this.mobileId=mobileId;
	}
	
	public String getname()
	{
		return name;
	}
	public void setname(String name)
	{
		this.name=name;
	}
	

	public int getprice()
	{
		return price;
	}
	public void setprice(int price)
	{
		this.price=price;
	}
	
	public int getquantity()
	{
		return quantity;
	}
	public void setquantity(int quantity)
	{
		this.quantity=quantity;
	}
}
