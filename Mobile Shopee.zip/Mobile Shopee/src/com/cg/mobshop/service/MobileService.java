package com.cg.mobshop.service;

public interface MobileService {
	public static void Mobilelist()
	{
		System.out.println("Sony xperia");
		System.out.println("Samsung note");
		System.out.println("Iphone 3");
		System.out.println("Nokia Note 2322");
	
	}

}
