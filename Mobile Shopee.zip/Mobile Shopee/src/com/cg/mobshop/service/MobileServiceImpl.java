package com.cg.mobshop.service;

public class MobileServiceImpl implements MobileService{
	public static void implementation()
	{
	MobileService.Mobilelist();
	}

}
