package com.cg.mobshop.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.MobileService;

public class MainUI {

	public static void main(String[] args) {
	System.out.println("***Welcome to Mobile Shopee***");
	System.out.println("________________________________");
	System.out.println("The avaialble mobile models are: ");
	
	   MobileService.Mobilelist();
	 
	    Mobiles obj1=new Mobiles(12,"Sony xperia",12000,101);
		Mobiles obj2=new Mobiles(4,"Samsung note",10000,102);
	    Mobiles obj3=new Mobiles(2,"Iphone 3",23000,103);
		Mobiles obj4=new Mobiles(8,"Nokia Note 2322",10000,104);

	ArrayList<Mobiles> hm=new ArrayList<Mobiles>();
	hm.add(obj1);
	hm.add(obj2);
	hm.add(obj3);
	hm.add(obj4);
	Scanner sc =new Scanner(System.in);
	System.out.println("");
	System.out.println("________________________________");
	System.out.println("Select sorting Criteria\n1.Mobile Name \n2.Mobile Price \n3.Mobile Quantity");
	System.out.println("");
	System.out.println("Enter option :");
	int ch=sc.nextInt();
	switch(ch)
	{
	case 1:
	{
	Comparator<Mobiles> cm1=Comparator.comparing(Mobiles::getname);
	Collections.sort(hm,cm1);
	for(Mobiles st:hm)
		System.out.println(st.name+" "+st.price+" "+st.mobileId+" "+st.quantity);
	break;
	}
	case 2:
	{
	Comparator<Mobiles> cm2=Comparator.comparing(Mobiles::getprice);
	Collections.sort(hm,cm2);
		for(Mobiles st:hm)
		System.out.println(st.name+" "+st.price+" "+st.mobileId+" "+st.quantity);
	break;
	}
	
	case 3:
	{
	Comparator<Mobiles> cm3=Comparator.comparing(Mobiles::getmobileId);
	Collections.sort(hm,cm3);
		for(Mobiles st:hm)
		System.out.println(st.name+" "+st.price+" "+st.mobileId+" "+st.quantity);
	break;
	   }

	}
	System.out.println("________________________________");
	System.out.println("Enter the MobileId to delete it from the list:");
	int remove=sc.nextInt();
	switch(remove)
	{
	case 101:hm.remove(obj1);break;
	case 102:hm.remove(obj2);break;
	case 103:hm.remove(obj3);break;
	case 104:hm.remove(obj4);break;
	}
	System.out.println("After removed item number from the list is:"+remove);
	sc.close();
      }
}
