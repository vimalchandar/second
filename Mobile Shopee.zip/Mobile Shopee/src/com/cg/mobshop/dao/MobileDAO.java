package com.cg.mobshop.dao;

public interface MobileDAO {
	public static void CustomerDetails()
	{
		System.out.println("The removed item number is:");
	}

}
