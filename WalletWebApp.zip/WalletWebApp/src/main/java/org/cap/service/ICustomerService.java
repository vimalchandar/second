package org.cap.service;

import org.cap.model.Customer;

public interface ICustomerService {
	public boolean createCustomer(Customer customer);
}
