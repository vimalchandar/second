package com.cp.modal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	

	@RequestMapping("/showPage")
	public String loginDirect(Model model)
	{
		String ur="John";
		model.addAttribute("username",ur);
		return "success";
	}
	
/*	@RequestMapping("/myLogin")
	public String loginCheck(@RequestParam("username") String uname,@RequestParam("password") String pwd, Model m)
	{	
		m.addAttribute("username1",uname);
		m.addAttribute("password1",pwd);
		return "success";
	}*/
	
	@RequestMapping("/myLogin")
	public String loginCheck(Login login)
	{
		if(login.getUsername().equals("John"))
			return "success";
		return "login";
	}
}

/*@RequestMapping("/myLogin")
public String loginCheck(@RequestParam("username") String uname,@RequestParam("password") String pwd, Model m)
{	
	m.addAttribute("username1",uname);
	m.addAttribute("password1",pwd);
	return "success";
}*/