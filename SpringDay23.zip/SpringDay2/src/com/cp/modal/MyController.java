package com.cp.modal;



import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	@Autowired
	Login login;
	
	@RequestMapping("/login")
	public String dispForm(Model m)
	{
		m.addAttribute("login",login);
		return "login";
		
	}

	@RequestMapping("/hello")
	public ModelAndView sayHello()
	{
		String today=new Date().toString();
		return new ModelAndView("hello","today",today);
	}
	
	
	public ModelAndView sayHi()
	{
		return new ModelAndView("login");
	}
}
