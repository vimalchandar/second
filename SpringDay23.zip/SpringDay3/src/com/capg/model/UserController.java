package com.capg.model;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value="user")
public class UserController {

	ArrayList<String> cityList;
	ArrayList<String> skillList;
	
	@RequestMapping(value="showRegister")
	public String func(Model model)
	{
		cityList = new ArrayList<String>();
		cityList.add("mumbai");
		cityList.add("hyderabad");
		cityList.add("chennai");
		cityList.add("pune");
		
		skillList = new ArrayList<String>();
		skillList.add("Java");
		skillList.add("C");
		skillList.add("C++");
		skillList.add("Hibernate");
		
		model.addAttribute("cityList",cityList);
		model.addAttribute("skillList",skillList);
		model.addAttribute("user",new User());
		return "register";
	}
	
/*	@RequestMapping(value="checkRegister")
	public String checkRegister(User user, Model model)
	{
		model.addAttribute("user",user);
		return "registerSuccess";
	}*/
	
	@RequestMapping(value="checkRegister")

		public String checkRegister(@ModelAttribute("user")@Valid User user,BindingResult result,Model model)
		{
			if(result.hasErrors())
			{
				System.out.println("Error");
				model.addAttribute("cityList",cityList);
				model.addAttribute("skillList",skillList);
				return "register";
			}
			else
			{
				model.addAttribute("user",user);
				return "registerSuccess";
			}
		}
}
