package com.capg.model;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Component
public class User {
	@NotEmpty(message="First Name is Mandatory")
	@Size(min=4,max=8,message="Minimum 4 and Maximum 8 characters required")
	private String firstName;
	
	@NotEmpty(message="Last Name is Mandatory")
	@Size(min=4,max=8,message="Minimum 4 and Maximum 8 characters required")
	private String lastName;
	
	private char gender;
	
	@Email(message="Please enter valud EMail Id")
	@NotEmpty(message="Email is Mandatory")
	private String email;
	private String[] skillSet;
	private String city;
	
	
	
	public User()
	{
		
	}
	
	public User(String firstName, String lastName, char gender, String email, String[] skillSet, String city) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.email = email;
		this.skillSet = skillSet;
		this.city = city;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String[] getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String[] skillSet) {
		this.skillSet = skillSet;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
}
